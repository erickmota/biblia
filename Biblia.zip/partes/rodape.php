<link rel="stylesheet" href="css_partes/rodape.css" type="text/css">

<div class="row mt-5">

    <div id="corpoRodape" class="col-12">

        <div class="row justify-content-center">

            <div class="col-9 mt-5 mb-4">

                <p class="text-light text-center">

                    Desenvolvido por Erick Mota - © Copyright 2024

                </p>

            </div>

        </div>

    </div>

</div>