<base href='http://localhost/Biblia/'>
<!-- <base href='http://localhost/novoAB/sistema/'> -->