<?php

echo "http://localhost/novoAB/sistema/";

?>